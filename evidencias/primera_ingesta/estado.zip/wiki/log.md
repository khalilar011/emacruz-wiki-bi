# Registro cronológico de operaciones

Fechas reales con desplazamiento UTC−04:00 (America/La_Paz). Operador: agente IA Codex. Aprobaciones humanas registradas por separado.

[Índice](index.md)

## 2026-11-03T21:05:36-04:00 — Preservación e inspección de fuentes

Se copiaron Excel y README locales sin alterar originales; se recuperó documentación de GitHub fijada por commit. El JSON solo se localizó en el árbol remoto y aún no se incorporó ni analizó. Hashes en [manifiesto](../fuentes/manifiesto.json). HTML leído como [texto completo](../fuentes/consigna/texto_completo.txt); prompt extraído de su sección 3. Se constató copia local antigua y ausencia local de AGENTS/JSON. Se emplea Python 3.14.3 estándar: openpyxl no instalado. El comando exploratorio `py --version` no existe y la enumeración de la carpeta personal fue denegada; no afectan las fuentes recuperadas.

## 2026-11-03T21:10:52-04:00 — Corrección del analizador antes de congelar la primera ingesta

La primera ejecución en [calculo](../evidencias/primera_ingesta/calculo/analisis.json) clasificó erróneamente banderas 0 como ausencias por usar `v or ""`. Se corrigió normalización para distinguir None de 0 y se repitió en [calculo_v1](../evidencias/primera_ingesta/calculo_v1/analisis.json). El KPI no cambió (6/21), pero el perfil de ausencias binarias sí. También se corrigió un paréntesis de impresión en preparar_fuentes.py tras un SyntaxError previo a su ejecución. Se conservan ambos resultados analíticos, sin presentar el inicial como validación final.

## 2026-11-03T21:10:52-04:00 — Primera ingesta ejecutada

Entradas: Excel, README y documentación de objetivos. Se generaron índice, objetivos, fuentes, diccionario, indicadores, hallazgos, procedencia, método, mapa, registro humano y README. [Inventario de archivos y aportes](../evidencias/primera_ingesta/operacion.json). KPI v1.0 = 6/21 (28,57 %); faltan horas Fin en quince filas. El JSON aún no se leyó. Las conclusiones están pendientes de revisión humana.
