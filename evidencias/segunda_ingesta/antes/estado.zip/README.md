# EMACRUZ – Wiki de conocimiento BI asistida por IA

Implementación académica independiente de Alerta Ruta, Business Intelligence II, Unidad 3, consigna 03/11/2026. Navegación: [wiki/index.md](wiki/index.md). La programación publicada permite diagnosticar calidad documental; no acredita servicio ejecutado, vigencia institucional ni predicción de acumulación.

La primera ingesta incorpora Excel y objetivos/documentación existentes. Se conserva una instantánea antes de la consulta y de incorporar JSON. Las conclusiones propuestas requieren [revisión humana](docs/revision_humana.md). El informe académico final y GitHub están reservados para otra tarea.

## Estructura

```text
emacruz-wiki-bi/
  fuentes/      originales, documentación remota fijada, consigna y hashes
  wiki/         índice, objetivos, fuentes, diccionario, KPI, hallazgos y log
  prompts/      original docente, versión EMACRUZ y justificación
  evidencias/   primera ingesta, consulta, segunda ingesta y revisión
  scripts/      lectura, cálculo y conservación de estados
  docs/         decisiones, mapa de trazabilidad y revisión humana
  AGENTS.md
  README.md
  requirements.txt
  .gitignore
```

## Reproducción

Python 3.10 o posterior; ejecución original con Python 3.14.3 en Windows. No requiere paquetes externos ni acceso de red para analizar las fuentes ya copiadas. Desde esta carpeta:

```powershell
python --version
python -X utf8 scripts/analizar.py --salida salidas/analisis_nuevo
```

Usar una carpeta nueva en cada ejecución: los scripts no sobrescriben evidencias históricas. La captura inicial de fuentes es específica del entorno de esta sesión; los cálculos posteriores leen las copias portables. Ver [método](docs/decisiones_metodologicas.md) y [reglas](AGENTS.md). No crear Git ni publicar automáticamente. Las exclusiones de copias originales se revisarán junto con permisos antes de una publicación futura.
