# Registro cronológico de operaciones

Fechas reales con desplazamiento UTC−04:00 (America/La_Paz). Operador: agente IA Codex. Aprobaciones humanas registradas por separado.

[Índice](index.md)

## 2026-11-03T21:05:36-04:00 — Preservación e inspección de fuentes

Se copiaron Excel y README locales sin alterar originales; se recuperó documentación de GitHub fijada por commit. El JSON solo se localizó en el árbol remoto y aún no se incorporó ni analizó. Hashes en [manifiesto](../fuentes/manifiesto.json). HTML leído como [texto completo](../fuentes/consigna/texto_completo.txt); prompt extraído de su sección 3. Se constató copia local antigua y ausencia local de AGENTS/JSON. Se emplea Python 3.14.3 estándar: openpyxl no instalado. El comando exploratorio `py --version` no existe y la enumeración de la carpeta personal fue denegada; no afectan las fuentes recuperadas.

## 2026-11-03T21:10:52-04:00 — Corrección del analizador antes de congelar la primera ingesta

La primera ejecución en [calculo](../evidencias/primera_ingesta/calculo/analisis.json) clasificó erróneamente banderas 0 como ausencias por usar `v or ""`. Se corrigió normalización para distinguir None de 0 y se repitió en [calculo_v1](../evidencias/primera_ingesta/calculo_v1/analisis.json). El KPI no cambió (6/21), pero el perfil de ausencias binarias sí. También se corrigió un paréntesis de impresión en preparar_fuentes.py tras un SyntaxError previo a su ejecución. Se conservan ambos resultados analíticos, sin presentar el inicial como validación final.

## 2026-11-03T21:10:52-04:00 — Primera ingesta ejecutada

Entradas: Excel, README y documentación de objetivos. Se generaron índice, objetivos, fuentes, diccionario, indicadores, hallazgos, procedencia, método, mapa, registro humano y README. [Inventario de archivos y aportes](../evidencias/primera_ingesta/operacion.json). KPI v1.0 = 6/21 (28,57 %); faltan horas Fin en quince filas. El JSON aún no se leyó. Las conclusiones están pendientes de revisión humana.

## 2026-11-03T21:10:52-04:00 — Instantánea primera_ingesta

Se conservó el estado real de 34 archivos en [primera_ingesta](../evidencias/primera_ingesta/estado.json), con ZIP y hashes. El propio asiento se añade después de la captura para evitar autorreferencia.

## 2026-11-03T21:12:23-04:00 — Consulta inicial desde la wiki

Se leyó primero índice y después objetivos, fuentes, indicadores, hallazgos y diccionario. [Orden y hashes](../evidencias/consulta_y_verificaciones/lectura_y_afirmaciones.json). Se guardó [respuesta inicial](../evidencias/consulta_y_verificaciones/respuesta_inicial.md) con tres afirmaciones derivadas del cálculo real: 21 filas, 15 sin Fin y 6 que cumplen. Todavía no se marca ninguna como contrastada por lectura independiente.

## 2026-11-03T21:13:03-04:00 — Consulta revisada y contrastada

V1, V2 y V3 confirmadas por lectura XML independiente. Se guardó wiki/consulta_negocio.md y se enlazó desde índice. Cifras iniciales conservadas; se precisó acción por grupo, alcance semanal y revisión humana pendiente. Auditoría de enlaces iniciada después de la consulta.

## 2026-11-03T21:14:22-04:00 — Auditoría y corrección antes de segunda ingesta

Se registró revisión semántica en wiki/revision_calidad.md y se incorporó al índice. Auditoría inicial: cuatro enlaces rotos. Se corrigió documento/generador y se repitió: evidencias/revision/enlaces_corregidos.json, 168 enlaces locales, cero rotos, cero páginas wiki aisladas y cero duplicados exactos. También se aclaró una errata del prompt sobre duplicados sin cambiar reglas. Pendientes: vigencia, mapas, imágenes, permisos y aceptación humana. Un parche de enlaces con fecha de ejecución mal transcrita fue rechazado sin modificar archivos y se reaplicó leyendo la fecha real.
