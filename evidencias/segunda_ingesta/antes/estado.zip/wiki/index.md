# EMACRUZ — índice de conocimiento

Estado: primera ingesta, versión 1.0. Fuentes conservadas y cálculos reales; conclusiones propuestas pendientes de revisión humana. La consulta, auditoría y segunda ingesta se ejecutarán después de congelar este estado.

- [objetivos ](objetivos.md)
- [fuentes ](fuentes.md)
- [diccionario datos ](diccionario_datos.md)
- [indicadores ](indicadores.md)
- [hallazgos ](hallazgos.md)
- [Consulta de negocio revisada](consulta_negocio.md)
- [Revisión de calidad](revision_calidad.md)
- [log ](log.md)

- [Reglas del agente](../AGENTS.md)
- [Procedencia](../fuentes/procedencia.md)
- [Prompt docente](../prompts/prompt_inicial.md), [mejorado](../prompts/prompt_mejorado.md) y [justificación](../prompts/justificacion_mejoras.md)
- [Decisiones metodológicas](../docs/decisiones_metodologicas.md)
- [Mapa de trazabilidad](../docs/mapa_trazabilidad.md)
- [Revisión humana](../docs/revision_humana.md)
- [Cálculo de primera ingesta](../evidencias/primera_ingesta/calculo_v1/analisis.json)
- [Inicio y reproducción](../README.md)
